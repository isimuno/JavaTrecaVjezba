package main.hr.java.covidportal.model;

/**
 * Sučelje zarazno koje sadrži metodu prelazakZarazeNaOsobu
 */
public interface Zarazno {

    void prelazakZarazeNaOsobu(Osoba osoba);
}
