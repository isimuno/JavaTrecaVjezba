package main.hr.java.covidportal.model;

/**
 * Klasa Simptom za kreiranje instance simptoma
 * nasljeđuje ImenovaniEntitet i njenu varijablu naziv
 */
public class Simptom extends ImenovaniEntitet {
    private String vrijednost;

    public Simptom(String naziv, String vrijednost) {
        super(naziv);
        this.vrijednost = vrijednost;
    }

    public String getVrijednost() {
        return vrijednost;
    }

    public void setVrijednost(String vrijednost) {
        this.vrijednost = vrijednost;
    }
}
