package main.hr.java.covidportal.iznimke;

/**
 * Klasa BolestIstihSimptomaException označava neoznačenu iznimku
 */

public class BolestIstihSimptomaException extends RuntimeException{


    public BolestIstihSimptomaException(String message) {
        super(message);
    }

    public BolestIstihSimptomaException(String message, Throwable cause) {
        super(message, cause);
    }

    public BolestIstihSimptomaException(Throwable cause) {
        super(cause);
    }
}
